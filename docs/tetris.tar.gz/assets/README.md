#  Tetris

**Tetris** is the classic 20th century game, now built with Python and Pygame. It’s designed for web deployment using **Pygbag**, making it accessible directly from your browser.

##  Play Now

 [Launch the Game on GitHub Pages](https://lawrencedaboss.github.io/tetris/)  
