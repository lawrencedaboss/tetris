import main
main.main()